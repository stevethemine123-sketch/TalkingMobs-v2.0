package br.com.talkingmobs.network;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraft.entity.player.EntityPlayerMP;

/** Sends only the recognized text to the logical server; raw microphone audio stays on the client. */
public final class VoiceTranscriptMessage implements IMessage {
    private String text = "";

    public VoiceTranscriptMessage() { }
    public VoiceTranscriptMessage(String text) {
        this.text = text == null ? "" : text.replace('\n', ' ').replace('\r', ' ').trim();
        if (this.text.length() > 500) this.text = this.text.substring(0, 500);
    }

    @Override public void fromBytes(ByteBuf buf) { text = ByteBufUtils.readUTF8String(buf); }
    @Override public void toBytes(ByteBuf buf) { ByteBufUtils.writeUTF8String(buf, text); }

    public static final class Handler implements IMessageHandler<VoiceTranscriptMessage, IMessage> {
        @Override public IMessage onMessage(final VoiceTranscriptMessage message, final MessageContext context) {
            final EntityPlayerMP player = context.getServerHandler().player;
            final String recognized = message.text == null ? "" : message.text.trim();
            if (recognized.isEmpty() || recognized.length() > 500) return null;
            player.getServer().addScheduledTask(new Runnable() {
                @Override public void run() {
                    player.getServer().getCommandManager().executeCommand(player,
                            "talkingmobs falar " + recognized.replace('\n', ' ').replace('\r', ' '));
                }
            });
            return null;
        }
    }
}
