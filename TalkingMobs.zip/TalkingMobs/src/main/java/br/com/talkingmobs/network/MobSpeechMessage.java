package br.com.talkingmobs.network;

import br.com.talkingmobs.client.LocalSpeechOutput;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.common.network.ByteBufUtils;

/** Delivers only the mob reply text to the client; synthesis stays on the client device. */
public final class MobSpeechMessage implements IMessage {
    private String text = "";
    public MobSpeechMessage() { }
    public MobSpeechMessage(String text) {
        this.text = text == null ? "" : text.replace('\n', ' ').replace('\r', ' ').trim();
        if (this.text.length() > 500) this.text = this.text.substring(0, 500);
    }
    @Override public void fromBytes(ByteBuf buf) { text = ByteBufUtils.readUTF8String(buf); }
    @Override public void toBytes(ByteBuf buf) { ByteBufUtils.writeUTF8String(buf, text); }
    public static final class Handler implements IMessageHandler<MobSpeechMessage, IMessage> {
        @Override public IMessage onMessage(final MobSpeechMessage message, MessageContext context) {
            if (message.text != null && !message.text.trim().isEmpty()) {
                try {
                    LocalSpeechOutput.speak(message.text);
                } catch (LinkageError unavailable) {
                    // Text replies remain usable when the client has no Java Sound implementation.
                }
            }
            return null;
        }
    }
}
