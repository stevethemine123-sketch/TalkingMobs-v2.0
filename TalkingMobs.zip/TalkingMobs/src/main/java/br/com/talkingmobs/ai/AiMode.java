package br.com.talkingmobs.ai;

public enum AiMode {
    ONLINE,
    OFFLINE,
    HYBRID;

    public static AiMode fromConfig(String value) {
        if (value == null) return HYBRID;
        try {
            return valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return HYBRID;
        }
    }
}
