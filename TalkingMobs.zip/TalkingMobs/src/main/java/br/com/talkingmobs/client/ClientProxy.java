package br.com.talkingmobs.client;

import br.com.talkingmobs.CommonProxy;
import br.com.talkingmobs.TalkingMobs;
import br.com.talkingmobs.network.MobSpeechMessage;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.FMLCommonHandler;
import org.lwjgl.input.Keyboard;

public final class ClientProxy extends CommonProxy {
    @Override public void registerClientFeatures() {
        // Packet registration must be identical for every client, including clients without Java Sound.
        TalkingMobs.NETWORK.registerMessage(MobSpeechMessage.Handler.class, MobSpeechMessage.class, 1, Side.CLIENT);
        try {
            Class.forName("javax.sound.sampled.AudioSystem");
        } catch (ClassNotFoundException | LinkageError unavailable) {
            // Android/Pojav builds without Java Sound keep text dialogue and networking available.
            return;
        }
        KeyBinding voiceKey = new KeyBinding("key.talkingmobs.voice", Keyboard.KEY_V, "key.categories.talkingmobs");
        ClientRegistry.registerKeyBinding(voiceKey);
        ClientVoiceCapture capture = new ClientVoiceCapture();
        FMLCommonHandler.instance().bus().register(new ClientVoiceKeyHandler(voiceKey, capture));
    }
}
