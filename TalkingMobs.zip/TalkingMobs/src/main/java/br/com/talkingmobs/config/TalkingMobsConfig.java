package br.com.talkingmobs.config;

import net.minecraftforge.common.config.Configuration;
import java.io.File;

public final class TalkingMobsConfig {
    public static final String CATEGORY_AI = "ai";
    public static final String CATEGORY_VOICE = "voice";
    public static final String CATEGORY_COMPAT = "compatibility";

    public static String aiMode = "HYBRID";
    public static String onlineEndpoint = "http://127.0.0.1:5000/v1/chat/completions";
    public static String onlineModel = "";
    public static String dialogueLanguage = "pt_br";
    public static String offlineEndpoint = "";
    public static boolean allowOnlineRequests = false;
    public static boolean rememberConversations = true;
    public static int maxMemoryEntries = 20;
    public static int maxConversationDistance = 16;
    public static boolean requirePushToTalk = true;
    public static boolean voiceChatIntegration = true;
    public static boolean speechRecognitionEnabled = false;
    public static String speechRecognitionEndpoint = "http://127.0.0.1:8765/transcribe";
    public static String speechRecognitionLanguage = "pt-BR";
    public static int maxSpeechAudioBytes = 2097152;
    public static boolean speechOutputEnabled = false;
    public static String speechOutputEndpoint = "http://127.0.0.1:8765/speak";

    private TalkingMobsConfig() { }

    public static void load(File file) {
        Configuration config = new Configuration(file);
        config.load();

        aiMode = config.getString("mode", CATEGORY_AI, "HYBRID",
                "AI mode: ONLINE, OFFLINE or HYBRID.");
        onlineEndpoint = config.getString("onlineEndpoint", CATEGORY_AI,
                "http://127.0.0.1:5000/v1/chat/completions", "OpenAI-compatible online/local endpoint.");
        onlineModel = config.getString("onlineModel", CATEGORY_AI, "", "Model identifier for the online endpoint.");
        dialogueLanguage = config.getString("dialogueLanguage", CATEGORY_AI, "pt_br", "Language code used for mob replies, e.g. pt_br or en_us.");
        offlineEndpoint = config.getString("offlineEndpoint", CATEGORY_AI,
                "", "Optional local OpenAI-compatible endpoint for offline AI (loopback only); blank disables HTTP calls.");
        allowOnlineRequests = config.getBoolean("allowOnlineRequests", CATEGORY_AI, false,
                "Must be enabled explicitly before sending conversation data to an online service.");
        rememberConversations = config.getBoolean("rememberConversations", CATEGORY_AI, true,
                "Keep a limited conversation memory for each player and mob.");
        maxMemoryEntries = config.getInt("maxMemoryEntries", CATEGORY_AI, 20, 1, 100,
                "Maximum remembered conversation entries per mob/player pair.");
        maxConversationDistance = config.getInt("maxConversationDistance", CATEGORY_VOICE, 16, 4, 64,
                "Maximum distance for a mob to respond to a player.");
        requirePushToTalk = config.getBoolean("requirePushToTalk", CATEGORY_VOICE, true,
                "Require an explicit push-to-talk action before voice capture.");
        voiceChatIntegration = config.getBoolean("simpleVoiceChatIntegration", CATEGORY_COMPAT, true,
                "Enable the optional Simple Voice Chat bridge when installed.");
        speechRecognitionEnabled = config.getBoolean("speechRecognitionEnabled", CATEGORY_VOICE, false,
                "Enable the optional local speech-to-text bridge. Disabled by default.");
        speechRecognitionEndpoint = config.getString("speechRecognitionEndpoint", CATEGORY_VOICE,
                "http://127.0.0.1:8765/transcribe", "Loopback-only local companion endpoint accepting WAV and returning JSON {text: ...}.");
        speechRecognitionLanguage = config.getString("speechRecognitionLanguage", CATEGORY_VOICE, "pt-BR",
                "Preferred recognition language, for example pt-BR or en-US.");
        maxSpeechAudioBytes = config.getInt("maxSpeechAudioBytes", CATEGORY_VOICE, 2097152, 1024, 10485760,
                "Maximum WAV payload size in bytes (1 KiB to 10 MiB).");
        speechOutputEnabled = config.getBoolean("speechOutputEnabled", CATEGORY_VOICE, false,
                "Enable optional local text-to-speech companion. Disabled by default.");
        speechOutputEndpoint = config.getString("speechOutputEndpoint", CATEGORY_VOICE,
                "http://127.0.0.1:8765/speak", "Loopback-only local companion endpoint accepting JSON {text, language} and returning WAV audio.");

        if (config.hasChanged()) config.save();
    }
}
