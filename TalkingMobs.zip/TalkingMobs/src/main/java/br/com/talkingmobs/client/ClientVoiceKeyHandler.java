package br.com.talkingmobs.client;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public final class ClientVoiceKeyHandler {
    private final KeyBinding key;
    private final ClientVoiceCapture capture;
    private boolean wasDown;
    public ClientVoiceKeyHandler(KeyBinding key, ClientVoiceCapture capture) { this.key = key; this.capture = capture; }

    @SubscribeEvent public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        boolean down = key.isKeyDown();
        if (down && !wasDown) capture.start();
        else if (!down && wasDown) capture.stop();
        wasDown = down;
    }
}
