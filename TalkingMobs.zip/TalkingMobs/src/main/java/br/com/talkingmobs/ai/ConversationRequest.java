package br.com.talkingmobs.ai;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

/** Immutable request passed from the Minecraft event layer to an AI provider. */
public final class ConversationRequest {
    private final UUID playerId;
    private final UUID entityId;
    private final String entityType;
    private final String entityName;
    private final String playerText;
    private final String locale;
    private final List<PersistentConversationMemory.Record> history;

    public ConversationRequest(UUID playerId, UUID entityId, String entityType, String playerText, String locale) {
        this(playerId, entityId, entityType, "criatura", playerText, locale, Collections.<PersistentConversationMemory.Record>emptyList());
    }

    public ConversationRequest(UUID playerId, UUID entityId, String entityType, String entityName, String playerText,
                               String locale, List<PersistentConversationMemory.Record> history) {
        this.playerId = playerId; this.entityId = entityId; this.entityType = entityType;
        this.entityName = entityName == null ? "criatura" : entityName;
        this.playerText = playerText; this.locale = locale;
        this.history = history == null ? Collections.<PersistentConversationMemory.Record>emptyList()
                : Collections.unmodifiableList(new java.util.ArrayList<PersistentConversationMemory.Record>(history));
    }
    public UUID getPlayerId() { return playerId; }
    public UUID getEntityId() { return entityId; }
    public String getEntityType() { return entityType; }
    public String getEntityName() { return entityName; }
    public String getPlayerText() { return playerText; }
    public String getLocale() { return locale; }
    public List<PersistentConversationMemory.Record> getHistory() { return history; }
}
