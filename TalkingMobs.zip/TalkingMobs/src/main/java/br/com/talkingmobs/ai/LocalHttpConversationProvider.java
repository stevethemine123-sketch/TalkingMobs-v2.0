package br.com.talkingmobs.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

/** Optional local model adapter. It is only selected for a loopback endpoint. */
public final class LocalHttpConversationProvider implements ConversationProvider {
    private final String endpoint;
    public LocalHttpConversationProvider(String endpoint) { this.endpoint = endpoint; }

    @Override public CompletableFuture<String> reply(final ConversationRequest request) {
        return CompletableFuture.supplyAsync(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(1500);
                connection.setReadTimeout(5000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                JsonObject body = new JsonObject();
                body.addProperty("model", "local");
                JsonArray messages = new JsonArray();
                JsonObject system = new JsonObject();
                system.addProperty("role", "system");
                system.addProperty("content", "Você interpreta " + request.getEntityName() + " no Minecraft. Tipo: " + request.getEntityType() + ". Responda em " + request.getLocale() + " com poucas frases, mantendo a personalidade e o contexto. Não afirme ações que não ocorreram no jogo.");
                messages.add(system);
                for (PersistentConversationMemory.Record entry : request.getHistory()) {
                    JsonObject user = new JsonObject(); user.addProperty("role", "user"); user.addProperty("content", entry.getPlayerText()); messages.add(user);
                    JsonObject assistant = new JsonObject(); assistant.addProperty("role", "assistant"); assistant.addProperty("content", entry.getReply()); messages.add(assistant);
                }
                JsonObject current = new JsonObject(); current.addProperty("role", "user"); current.addProperty("content", request.getPlayerText()); messages.add(current);
                body.add("messages", messages);
                byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = connection.getOutputStream()) { out.write(payload); }
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                if (stream == null) throw new IllegalStateException("Resposta vazia do serviço local (HTTP " + status + ")");
                StringBuilder response = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (response.length() + line.length() > 65536)
                            throw new IllegalStateException("Resposta do serviço local excede 64 KiB.");
                        response.append(line);
                    }
                }
                if (status < 200 || status >= 300) throw new IllegalStateException("Serviço local retornou HTTP " + status);
                JsonObject json = new JsonParser().parse(response.toString()).getAsJsonObject();
                String content = json.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message").get("content").getAsString();
                if (content.trim().isEmpty()) throw new IllegalStateException("O serviço local retornou uma resposta vazia");
                return content.trim().substring(0, Math.min(1000, content.trim().length()));
            } catch (Exception ex) {
                throw new RuntimeException("Falha na IA local: " + ex.getMessage(), ex);
            } finally { if (connection != null) connection.disconnect(); }
        });
    }
    @Override public String getProviderName() { return "local-http"; }
}
