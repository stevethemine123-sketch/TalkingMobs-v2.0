package br.com.talkingmobs.client;

import br.com.talkingmobs.TalkingMobs;
import br.com.talkingmobs.config.TalkingMobsConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;

/** Optional loopback-only TTS bridge. Audio is synthesized and played on the client. */
public final class LocalSpeechOutput {
    private LocalSpeechOutput() { }
    public static void speak(final String text) {
        if (!TalkingMobsConfig.speechOutputEnabled || text == null || text.trim().isEmpty()) return;
        Thread worker = new Thread(new Runnable() { @Override public void run() { synthesizeAndPlay(text); } }, "TalkingMobs-TTS");
        worker.setDaemon(true); worker.start();
    }
    private static void synthesizeAndPlay(String text) {
        HttpURLConnection connection = null;
        try {
            URI uri = new URI(TalkingMobsConfig.speechOutputEndpoint);
            if (!"http".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null || !InetAddress.getByName(uri.getHost()).isLoopbackAddress())
                throw new IllegalArgumentException("A voz exige um endpoint HTTP local (127.0.0.1/localhost).");
            connection = (HttpURLConnection) uri.toURL().openConnection();
            connection.setRequestMethod("POST"); connection.setConnectTimeout(2000); connection.setReadTimeout(10000);
            connection.setDoOutput(true); connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            String json = "{\"text\":\"" + escape(text) + "\",\"language\":\"" + escape(TalkingMobsConfig.dialogueLanguage) + "\"}";
            byte[] body = json.getBytes(StandardCharsets.UTF_8); connection.setFixedLengthStreamingMode(body.length);
            OutputStream out = connection.getOutputStream(); out.write(body); out.close();
            if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 300) throw new IllegalStateException("Serviço TTS respondeu HTTP " + connection.getResponseCode());
            InputStream in = connection.getInputStream(); ByteArrayOutputStream audio = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096]; int n; while ((n = in.read(buffer)) != -1) { if (audio.size() + n > 5 * 1024 * 1024) throw new IllegalStateException("Áudio TTS excede 5 MiB."); audio.write(buffer,0,n); } in.close();
            byte[] wav = audio.toByteArray();
            AudioInputStream stream = AudioSystem.getAudioInputStream(new ByteArrayInputStream(wav));
            final Clip clip = AudioSystem.getClip(); clip.open(stream); clip.start();
        } catch (LinkageError unavailable) { notifyClient("Saída de voz não está disponível neste cliente; use texto ou um adaptador de áudio nativo."); }
          catch (Exception error) { notifyClient("Não foi possível reproduzir a voz do mob: " + error.getMessage()); }
        finally { if (connection != null) connection.disconnect(); }
    }
    private static String escape(String value) { return value.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ").replace("\r"," "); }
    private static void notifyClient(final String message) { Minecraft.getMinecraft().addScheduledTask(new Runnable() { @Override public void run() { if (Minecraft.getMinecraft().player != null) Minecraft.getMinecraft().player.sendMessage(new TextComponentString("§6[Talking Mobs]§r " + message)); } }); }
}
