package br.com.talkingmobs.ai;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraftforge.common.util.Constants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/** World-persistent, bounded memory. Stored in the server world's data folder. */
public final class PersistentConversationMemory extends WorldSavedData {
    private static final String DATA_NAME = "talkingmobs_memory";
    private static final int MAX_RECORDS = 8192;
    private final List<Record> records = new ArrayList<Record>();

    public PersistentConversationMemory() { super(DATA_NAME); }
    public PersistentConversationMemory(String name) { super(name); }

    public static PersistentConversationMemory get(World world) {
        if (world == null || world.isRemote) return null;
        MapStorage storage = world.getPerWorldStorage();
        PersistentConversationMemory data = (PersistentConversationMemory)
                storage.getOrLoadData(PersistentConversationMemory.class, DATA_NAME);
        if (data == null) {
            data = new PersistentConversationMemory();
            storage.setData(DATA_NAME, data);
        }
        return data;
    }

    public synchronized void add(UUID playerId, UUID entityId, String playerText, String reply, int maxPerPair) {
        if (playerId == null || entityId == null) return;
        records.add(new Record(playerId.toString(), entityId.toString(), safe(playerText), safe(reply)));
        int pairCount = 0;
        for (int i = records.size() - 1; i >= 0; i--) {
            Record record = records.get(i);
            if (record.playerId.equals(playerId.toString()) && record.entityId.equals(entityId.toString())) {
                pairCount++;
                if (pairCount > Math.max(1, maxPerPair)) records.remove(i);
            }
        }
        while (records.size() > MAX_RECORDS) records.remove(0);
        markDirty();
    }

    public synchronized List<Record> get(UUID playerId, UUID entityId, int limit) {
        if (playerId == null || entityId == null) return Collections.emptyList();
        List<Record> result = new ArrayList<Record>();
        for (int i = records.size() - 1; i >= 0 && result.size() < Math.max(1, limit); i--) {
            Record record = records.get(i);
            if (record.playerId.equals(playerId.toString()) && record.entityId.equals(entityId.toString())) result.add(record);
        }
        Collections.reverse(result);
        return Collections.unmodifiableList(result);
    }

    @Override
    public synchronized void readFromNBT(NBTTagCompound compound) {
        records.clear();
        NBTTagList list = compound.getTagList("records", Constants.NBT.TAG_COMPOUND);
        int start = Math.max(0, list.tagCount() - MAX_RECORDS);
        for (int i = start; i < list.tagCount(); i++) {
            NBTTagCompound item = list.getCompoundTagAt(i);
            String player = item.getString("player");
            String entity = item.getString("entity");
            if (player.isEmpty() || entity.isEmpty()) continue;
            records.add(new Record(player, entity, item.getString("input"), item.getString("reply")));
        }
    }

    @Override
    public synchronized NBTTagCompound writeToNBT(NBTTagCompound compound) {
        NBTTagList list = new NBTTagList();
        for (Record record : records) {
            NBTTagCompound item = new NBTTagCompound();
            item.setString("player", record.playerId);
            item.setString("entity", record.entityId);
            item.setString("input", record.playerText);
            item.setString("reply", record.reply);
            list.appendTag(item);
        }
        compound.setTag("records", list);
        return compound;
    }

    private static String safe(String value) { return value == null ? "" : value.substring(0, Math.min(value.length(), 1000)); }

    public static final class Record {
        private final String playerId, entityId, playerText, reply;
        private Record(String playerId, String entityId, String playerText, String reply) {
            this.playerId = playerId; this.entityId = entityId; this.playerText = playerText; this.reply = reply;
        }
        public String getPlayerText() { return playerText; }
        public String getReply() { return reply; }
    }
}
