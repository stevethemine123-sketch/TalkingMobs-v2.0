package br.com.talkingmobs.dialogue;

import br.com.talkingmobs.ai.ConversationRequest;
import br.com.talkingmobs.ai.ConversationService;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.LinkedHashMap;
import java.util.Map;

/** First interactive bridge from Forge events to the asynchronous dialogue service. */
public final class VillagerDialogueHandler {
    private static final long COOLDOWN_TICKS = 60L;
    private static final int MAX_TRACKED_PAIRS = 4096;
    private static final Map<String, Long> LAST_DIALOGUE = new LinkedHashMap<String, Long>(128, 0.75F, true) {
        private static final long serialVersionUID = 1L;
        @Override protected boolean removeEldestEntry(Map.Entry<String, Long> eldest) {
            return size() > MAX_TRACKED_PAIRS;
        }
    };
    private final ConversationService conversationService = new ConversationService();

    @SubscribeEvent
    public void onLivingEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getWorld().isRemote) return;

        Entity target = event.getTarget();
        if (!(target instanceof EntityLivingBase) || target instanceof EntityPlayer) return;
        EntityLivingBase living = (EntityLivingBase) target;
        final EntityPlayer player = event.getEntityPlayer();
        if (player == null || living.isDead) return;

        long now = event.getWorld().getTotalWorldTime();
        String key = player.getUniqueID().toString() + ":" + living.getUniqueID().toString();
        Long previous = LAST_DIALOGUE.get(key);
        if (previous != null && now - previous.longValue() < COOLDOWN_TICKS) return;
        LAST_DIALOGUE.put(key, Long.valueOf(now));

        final String entityName = living.getName();
        final net.minecraft.world.World world = event.getWorld();
        final java.util.UUID playerId = player.getUniqueID();
        ConversationRequest request = new ConversationRequest(
                playerId, living.getUniqueID(), classify(living), entityName,
                "interagir", "pt_br", java.util.Collections.<br.com.talkingmobs.ai.PersistentConversationMemory.Record>emptyList());
        final MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        if (server == null) return;

        conversationService.respond(world, request).thenAccept(reply -> server.addScheduledTask(() -> {
            conversationService.remember(world, request, reply);
            EntityPlayer onlinePlayer = server.getPlayerList().getPlayerByUUID(playerId);
            if (onlinePlayer != null) {
                onlinePlayer.sendMessage(new TextComponentString("§6[" + entityName + "]§r " + reply));
            }
        })).exceptionally(error -> {
            server.addScheduledTask(() -> {
                EntityPlayer onlinePlayer = server.getPlayerList().getPlayerByUUID(playerId);
                if (onlinePlayer != null) onlinePlayer.sendMessage(new TextComponentString("§cNão consegui gerar uma resposta para esse mob."));
            });
            return null;
        });
    }

    private static String classify(EntityLivingBase entity) {
        if (entity instanceof EntityVillager) return "villager";
        if (entity instanceof EntityAnimal) return "animal";
        if (entity instanceof EntityMob) return "hostile";
        return "other";
    }
}
