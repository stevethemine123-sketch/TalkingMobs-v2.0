package br.com.talkingmobs.ai;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Bounded, server-session memory. It is intentionally not persisted to disk yet. */
public final class ConversationMemory {
    private final Map<String, Deque<Entry>> conversations = new HashMap<String, Deque<Entry>>();
    private final int maxEntries;
    private final int maxPairs;

    public ConversationMemory(int maxEntries, int maxPairs) {
        this.maxEntries = Math.max(1, maxEntries);
        this.maxPairs = Math.max(1, maxPairs);
    }

    public synchronized void add(UUID playerId, UUID entityId, String playerText, String reply) {
        if (playerId == null || entityId == null) return;
        String key = key(playerId, entityId);
        Deque<Entry> entries = conversations.get(key);
        if (entries == null) {
            if (conversations.size() >= maxPairs) {
                String oldestKey = conversations.keySet().iterator().next();
                conversations.remove(oldestKey);
            }
            entries = new ArrayDeque<Entry>();
            conversations.put(key, entries);
        }
        entries.addLast(new Entry(safe(playerText), safe(reply)));
        while (entries.size() > maxEntries) entries.removeFirst();
    }

    public synchronized List<Entry> get(UUID playerId, UUID entityId) {
        Deque<Entry> entries = conversations.get(key(playerId, entityId));
        if (entries == null) return Collections.emptyList();
        return Collections.unmodifiableList(new ArrayList<Entry>(entries));
    }

    public synchronized void clear() { conversations.clear(); }

    private static String key(UUID playerId, UUID entityId) {
        return playerId.toString() + ":" + entityId.toString();
    }

    private static String safe(String value) { return value == null ? "" : value; }

    public static final class Entry {
        private final String playerText;
        private final String reply;
        private Entry(String playerText, String reply) {
            this.playerText = playerText;
            this.reply = reply;
        }
        public String getPlayerText() { return playerText; }
        public String getReply() { return reply; }
    }
}
