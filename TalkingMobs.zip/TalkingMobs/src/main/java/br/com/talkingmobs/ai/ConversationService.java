package br.com.talkingmobs.ai;

import br.com.talkingmobs.config.TalkingMobsConfig;
import net.minecraft.world.World;
import java.net.InetAddress;
import java.net.URI;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Provider selection, bounded persistent memory and privacy-safe fallback. */
public final class ConversationService {
    private final ConversationProvider fallback = new LocalConversationProvider();

    public CompletableFuture<String> respond(final World world, final ConversationRequest request) {
        final PersistentConversationMemory saved = PersistentConversationMemory.get(world);
        final List<PersistentConversationMemory.Record> history = saved == null
                ? java.util.Collections.<PersistentConversationMemory.Record>emptyList()
                : saved.get(request.getPlayerId(), request.getEntityId(), TalkingMobsConfig.maxMemoryEntries);
        final ConversationRequest enriched = new ConversationRequest(request.getPlayerId(), request.getEntityId(),
                request.getEntityType(), request.getEntityName(), request.getPlayerText(), request.getLocale(), history);

        CompletableFuture<String> generated = fallback.reply(enriched);
        if ("OFFLINE".equalsIgnoreCase(TalkingMobsConfig.aiMode) || "HYBRID".equalsIgnoreCase(TalkingMobsConfig.aiMode)) {
            if (isLoopbackEndpoint(TalkingMobsConfig.offlineEndpoint)) {
                generated = new LocalHttpConversationProvider(TalkingMobsConfig.offlineEndpoint).reply(enriched)
                        .exceptionally(error -> null).thenCompose(reply -> reply == null ? fallback.reply(enriched) : CompletableFuture.completedFuture(reply));
            }
        } else if ("ONLINE".equalsIgnoreCase(TalkingMobsConfig.aiMode) && TalkingMobsConfig.allowOnlineRequests) {
            // Deliberately not implemented yet: online providers require an explicit privacy/key design.
            generated = fallback.reply(enriched);
        }
        return generated;
    }

    /** Must be called on the Minecraft server thread after the reply is delivered. */
    public void remember(World world, ConversationRequest request, String reply) {
        if (!TalkingMobsConfig.rememberConversations) return;
        PersistentConversationMemory saved = PersistentConversationMemory.get(world);
        if (saved != null) saved.add(request.getPlayerId(), request.getEntityId(), request.getPlayerText(), reply,
                TalkingMobsConfig.maxMemoryEntries);
    }

    private static boolean isLoopbackEndpoint(String endpoint) {
        try {
            URI uri = new URI(endpoint);
            if (!"http".equalsIgnoreCase(uri.getScheme()) && !"https".equalsIgnoreCase(uri.getScheme())) return false;
            String host = uri.getHost();
            return host != null && InetAddress.getByName(host).isLoopbackAddress();
        } catch (Exception ignored) { return false; }
    }
}
