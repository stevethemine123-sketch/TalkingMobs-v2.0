package br.com.talkingmobs.voice;

import java.util.concurrent.CompletableFuture;

/** Converts a WAV recording to text. Implementations must never capture audio implicitly. */
public interface SpeechRecognitionProvider {
    CompletableFuture<String> transcribe(byte[] wavAudio, String language);
    String getProviderName();
}
