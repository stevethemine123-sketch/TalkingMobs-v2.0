package br.com.talkingmobs;

public class CommonProxy {
    public void registerClientFeatures() { }
}
