package br.com.talkingmobs.ai;

import java.util.concurrent.CompletableFuture;

/** Safe built-in fallback: no network calls and no external data sharing. */
public final class LocalConversationProvider implements ConversationProvider {
    @Override
    public CompletableFuture<String> reply(final ConversationRequest request) {
        return CompletableFuture.supplyAsync(() -> createReply(request));
    }

    private String createReply(ConversationRequest request) {
        String type = request.getEntityType() == null ? "" : request.getEntityType().toLowerCase();
        String text = request.getPlayerText() == null ? "" : request.getPlayerText().trim().toLowerCase();
        if (text.contains("olá") || text.contains("oi") || text.equals("hello")) {
            return type.contains("villager") ? "Olá, viajante! Que notícias traz da estrada?" : "Olá! Estou ouvindo você.";
        }
        if (text.contains("ajuda") || text.contains("help")) {
            return type.contains("hostile")
                    ? "Não sei se posso confiar em você..." : "Talvez eu possa ajudar. O que aconteceu?";
        }
        if (text.contains("perigo") || text.contains("danger")) {
            return "Fique atento. Este lugar pode não ser seguro.";
        }
        if (type.contains("villager")) return "Hmm... interessante. Conte-me mais.";
        if (type.contains("animal")) return "O animal reage à sua voz, mas não parece entender as palavras.";
        if (type.contains("hostile")) return "A criatura observa você com desconfiança.";
        return "A criatura parece prestar atenção, mas ainda não sabe como responder.";
    }

    @Override public String getProviderName() { return "local-fallback"; }
}
