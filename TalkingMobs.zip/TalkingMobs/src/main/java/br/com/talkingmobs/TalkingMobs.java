package br.com.talkingmobs;

import br.com.talkingmobs.command.TalkingMobsCommand;
import br.com.talkingmobs.network.VoiceTranscriptMessage;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;
import br.com.talkingmobs.dialogue.VillagerDialogueHandler;
import net.minecraftforge.common.MinecraftForge;
import br.com.talkingmobs.config.TalkingMobsConfig;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import org.apache.logging.log4j.Logger;

@Mod(modid = TalkingMobs.MODID, name = TalkingMobs.NAME, version = TalkingMobs.VERSION,
        acceptedMinecraftVersions = "[1.12.2]", dependencies = "after:voicechat")
public class TalkingMobs {
    public static final String MODID = "talkingmobs";
    public static final String NAME = "Talking Mobs";
    public static final String VERSION = "0.1.8-dev";

    @Mod.Instance(MODID)
    public static TalkingMobs INSTANCE;

    public static Logger LOGGER;
    public static final SimpleNetworkWrapper NETWORK = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);

    @SidedProxy(clientSide = "br.com.talkingmobs.client.ClientProxy", serverSide = "br.com.talkingmobs.CommonProxy")
    public static CommonProxy PROXY;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        LOGGER = event.getModLog();
        TalkingMobsConfig.load(event.getSuggestedConfigurationFile());
        LOGGER.info("Talking Mobs starting. Voice chat integration is detected separately from the AI backend.");
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new VillagerDialogueHandler());
        NETWORK.registerMessage(VoiceTranscriptMessage.Handler.class, VoiceTranscriptMessage.class, 0, Side.SERVER);
        PROXY.registerClientFeatures();
        LOGGER.info("Talking Mobs core initialized. Mob dialogue and /talkingmobs falar are active.");
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        LOGGER.info("Talking Mobs post-initialization complete.");
    }

    @EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new TalkingMobsCommand());
    }
}
