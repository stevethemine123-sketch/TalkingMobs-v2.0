package br.com.talkingmobs.command;

import br.com.talkingmobs.TalkingMobs;
import br.com.talkingmobs.ai.AiMode;
import br.com.talkingmobs.ai.ConversationRequest;
import br.com.talkingmobs.ai.ConversationService;
import br.com.talkingmobs.compat.voicechat.VoiceChatCompat;
import br.com.talkingmobs.network.MobSpeechMessage;
import br.com.talkingmobs.config.TalkingMobsConfig;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import java.util.List;

public class TalkingMobsCommand extends CommandBase {
    private final ConversationService conversations = new ConversationService();
    @Override public String getName() { return "talkingmobs"; }
    @Override public String getUsage(ICommandSender sender) { return "/talkingmobs <falar|status> [mensagem]"; }
    @Override public int getRequiredPermissionLevel() { return 0; }

    @Override
    public void execute(final MinecraftServer server, final ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0 || "status".equalsIgnoreCase(args[0])) {
            sender.sendMessage(new TextComponentString("[Talking Mobs] " + TalkingMobs.VERSION));
            sender.sendMessage(new TextComponentString("Modo configurado: " + AiMode.fromConfig(TalkingMobsConfig.aiMode)));
            sender.sendMessage(new TextComponentString("IA local: fallback ativo; endpoint local usado apenas em OFFLINE/HYBRID."));
            sender.sendMessage(new TextComponentString("Envio online: " + (TalkingMobsConfig.allowOnlineRequests ? "permitido na configuração, mas adaptador ainda não implementado" : "desativado")));
            sender.sendMessage(new TextComponentString("Simple Voice Chat: " + (VoiceChatCompat.isInstalled() ? "detectado" : "não detectado")));
            sender.sendMessage(new TextComponentString("Reconhecimento de voz: " + (TalkingMobsConfig.speechRecognitionEnabled ? "ponte local habilitada" : "desativado")));
            sender.sendMessage(new TextComponentString("Captura de microfone: tecla V no cliente (Java Sound; suporte Android dedicado pendente)."));
            return;
        }
        if ("falar".equalsIgnoreCase(args[0]) || "talk".equalsIgnoreCase(args[0])) {
            if (!(sender instanceof EntityPlayerMP)) throw new CommandException("Este comando precisa ser usado por um jogador.");
            if (args.length < 2) throw new CommandException("Use /talkingmobs falar <mensagem>");
            final EntityPlayerMP player = (EntityPlayerMP) sender;
            final StringBuilder text = new StringBuilder();
            for (int i = 1; i < args.length; i++) { if (i > 1) text.append(' '); text.append(args[i]); }
            final String message = text.toString().trim();
            if (message.isEmpty()) throw new CommandException("Digite uma mensagem para o mob.");
            if (message.length() > 500) throw new CommandException("A mensagem deve ter no máximo 500 caracteres.");
            final World world = player.world;
            final double range = TalkingMobsConfig.maxConversationDistance;
            AxisAlignedBB area = player.getEntityBoundingBox().grow(range);
            List<EntityLivingBase> nearby = world.getEntitiesWithinAABB(EntityLivingBase.class, area,
                    entity -> !(entity instanceof EntityPlayer) && !entity.isDead);
            EntityLivingBase nearest = null;
            double nearestDistance = range * range;
            for (EntityLivingBase entity : nearby) {
                double distance = player.getDistanceSq(entity);
                if (distance <= nearestDistance) { nearest = entity; nearestDistance = distance; }
            }
            if (nearest == null) throw new CommandException("Não há nenhum mob por perto. Aproxime-se de uma criatura.");
            final EntityLivingBase target = nearest;
            final String targetName = target.getName();
            final String targetType = target.getClass().getName().toLowerCase().contains("villager") ? "villager" :
                    target.isCreatureType(net.minecraft.entity.EnumCreatureType.MONSTER, false) ? "hostile" :
                    target.isCreatureType(net.minecraft.entity.EnumCreatureType.CREATURE, false) ? "animal" : "other";
            final java.util.UUID playerId = player.getUniqueID();
            final java.util.UUID targetId = target.getUniqueID();
            player.sendMessage(new TextComponentString("§7Você falou com " + targetName + "..."));
            ConversationRequest request = new ConversationRequest(playerId, targetId, targetType, targetName, message,
                    TalkingMobsConfig.dialogueLanguage, java.util.Collections.<br.com.talkingmobs.ai.PersistentConversationMemory.Record>emptyList());
            conversations.respond(world, request).thenAccept(reply -> {
                server.addScheduledTask(() -> {
                    EntityPlayerMP online = server.getPlayerList().getPlayerByUUID(playerId);
                    conversations.remember(world, request, reply);
                    if (online != null && online.dimension == world.provider.getDimension()) {
                        online.sendMessage(new TextComponentString("§6[" + targetName + "]§r " + reply));
                        TalkingMobs.NETWORK.sendTo(new MobSpeechMessage(reply), online);
                    }
                });
            }).exceptionally(error -> {
                server.addScheduledTask(() -> {
                    EntityPlayerMP online = server.getPlayerList().getPlayerByUUID(playerId);
                    if (online != null) online.sendMessage(new TextComponentString("§cNão consegui gerar uma resposta para esse mob."));
                });
                return null;
            });
            return;
        }
        sender.sendMessage(new TextComponentString(getUsage(sender)));
    }
}
