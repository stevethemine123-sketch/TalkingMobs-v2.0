package br.com.talkingmobs.client;

import br.com.talkingmobs.TalkingMobs;
import br.com.talkingmobs.config.TalkingMobsConfig;
import br.com.talkingmobs.network.VoiceTranscriptMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.TargetDataLine;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

/** Desktop Java Sound capture backend. Android runtimes without Java Sound fail gracefully. */
public final class ClientVoiceCapture {
    private static final AudioFormat FORMAT = new AudioFormat(16000.0f, 16, 1, true, false);
    private static final int MAX_SECONDS = 8;
    private final AtomicBoolean capturing = new AtomicBoolean(false);
    private volatile TargetDataLine activeLine;

    public void start() {
        if (!TalkingMobsConfig.speechRecognitionEnabled) {
            tell("Reconhecimento de voz está desativado na configuração.");
            return;
        }
        if (!capturing.compareAndSet(false, true)) return;
        tell("Microfone ativado. Fale agora; solte a tecla para terminar (máximo de 8 segundos).");
        Thread worker = new Thread(new Runnable() {
            @Override public void run() { captureAndTranscribe(); }
        }, "TalkingMobs-Microphone");
        worker.setDaemon(true);
        worker.start();
    }

    public void stop() {
        capturing.set(false);
        TargetDataLine line = activeLine;
        if (line != null) line.stop();
    }

    private void captureAndTranscribe() {
        TargetDataLine line = null;
        try {
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);
            line = (TargetDataLine) AudioSystem.getLine(info);
            activeLine = line;
            line.open(FORMAT);
            line.start();
            ByteArrayOutputStream pcm = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            long deadline = System.currentTimeMillis() + MAX_SECONDS * 1000L;
            while (capturing.get() && System.currentTimeMillis() < deadline) {
                int count = line.read(buffer, 0, buffer.length);
                if (count > 0) pcm.write(buffer, 0, count);
            }
            line.stop();
            line.close();
            activeLine = null;
            capturing.set(false);
            byte[] wav = toWav(pcm.toByteArray());
            if (wav.length <= 44) { tell("Nenhum áudio foi capturado."); return; }
            new br.com.talkingmobs.voice.LocalHttpSpeechRecognitionProvider(
                    TalkingMobsConfig.speechRecognitionEndpoint, TalkingMobsConfig.maxSpeechAudioBytes)
                    .transcribe(wav, TalkingMobsConfig.speechRecognitionLanguage)
                    .thenAccept(text -> Minecraft.getMinecraft().addScheduledTask(new Runnable() {
                        @Override public void run() {
                            if (Minecraft.getMinecraft().player != null) {
                                Minecraft.getMinecraft().player.sendMessage(new TextComponentString("§7Você: " + text));
                                TalkingMobs.NETWORK.sendToServer(new VoiceTranscriptMessage(text));
                            }
                        }
                    })).exceptionally(error -> {
                        tell("Falha ao reconhecer a fala: " + rootMessage(error));
                        return null;
                    });
        } catch (LinkageError error) {
            tell("Este ambiente não oferece a API de microfone Java Sound. No Android será necessário um adaptador próprio.");
        } catch (Exception error) {
            tell("Não foi possível acessar o microfone ou o serviço local: " + rootMessage(error));
        } finally {
            if (line != null) { try { line.close(); } catch (Exception ignored) { } }
            activeLine = null;
            capturing.set(false);
        }
    }

    private static byte[] toWav(byte[] pcm) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(44 + pcm.length);
        DataOutputStream out = new DataOutputStream(bytes);
        writeAscii(out, "RIFF"); writeIntLE(out, 36 + pcm.length); writeAscii(out, "WAVE");
        writeAscii(out, "fmt "); writeIntLE(out, 16); writeShortLE(out, 1); writeShortLE(out, 1);
        writeIntLE(out, 16000); writeIntLE(out, 32000); writeShortLE(out, 2); writeShortLE(out, 16);
        writeAscii(out, "data"); writeIntLE(out, pcm.length); out.write(pcm); out.flush();
        return bytes.toByteArray();
    }
    private static void writeAscii(DataOutputStream out, String value) throws IOException { out.writeBytes(value); }
    private static void writeIntLE(DataOutputStream out, int value) throws IOException {
        out.write(value & 255); out.write((value >>> 8) & 255); out.write((value >>> 16) & 255); out.write((value >>> 24) & 255);
    }
    private static void writeShortLE(DataOutputStream out, int value) throws IOException { out.write(value & 255); out.write((value >>> 8) & 255); }
    private static String rootMessage(Throwable error) {
        Throwable root = error; while (root.getCause() != null) root = root.getCause();
        return root.getMessage() == null ? root.getClass().getSimpleName() : root.getMessage();
    }
    private static void tell(final String message) {
        Minecraft.getMinecraft().addScheduledTask(new Runnable() {
            @Override public void run() {
                if (Minecraft.getMinecraft().player != null)
                    Minecraft.getMinecraft().player.sendMessage(new TextComponentString("§6[Talking Mobs]§r " + message));
            }
        });
    }
}
