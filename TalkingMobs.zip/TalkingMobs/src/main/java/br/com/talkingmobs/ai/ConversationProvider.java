package br.com.talkingmobs.ai;

import java.util.concurrent.CompletableFuture;

/** Implementations must perform network/model work off the Minecraft server thread. */
public interface ConversationProvider {
    CompletableFuture<String> reply(ConversationRequest request);
    String getProviderName();
}
