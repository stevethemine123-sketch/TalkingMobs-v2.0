package br.com.talkingmobs.voice;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

/** Optional loopback-only adapter for a local speech-to-text companion service. */
public final class LocalHttpSpeechRecognitionProvider implements SpeechRecognitionProvider {
    private final String endpoint;
    private final int maxBytes;

    public LocalHttpSpeechRecognitionProvider(String endpoint, int maxBytes) {
        this.endpoint = endpoint;
        this.maxBytes = Math.max(1024, Math.min(maxBytes, 10 * 1024 * 1024));
    }

    @Override public CompletableFuture<String> transcribe(final byte[] wavAudio, final String language) {
        return CompletableFuture.supplyAsync(() -> {
            if (wavAudio == null || wavAudio.length < 44 || wavAudio.length > maxBytes)
                throw new IllegalArgumentException("Áudio WAV ausente ou fora do limite configurado.");
            if (wavAudio[0] != 'R' || wavAudio[1] != 'I' || wavAudio[2] != 'F' || wavAudio[3] != 'F'
                    || wavAudio[8] != 'W' || wavAudio[9] != 'A' || wavAudio[10] != 'V' || wavAudio[11] != 'E')
                throw new IllegalArgumentException("O áudio precisa estar no formato WAV.");
            HttpURLConnection connection = null;
            try {
                URI uri = new URI(endpoint);
                if (!"http".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null
                        || !InetAddress.getByName(uri.getHost()).isLoopbackAddress())
                    throw new IllegalStateException("O reconhecimento de voz aceita somente um serviço HTTP local (localhost).");
                connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(1500);
                connection.setReadTimeout(15000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "audio/wav");
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("X-Speech-Language", language == null ? "pt-BR" : language);
                connection.setFixedLengthStreamingMode(wavAudio.length);
                try (OutputStream out = connection.getOutputStream()) { out.write(wavAudio); }
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                if (stream == null) throw new IllegalStateException("Serviço de voz sem resposta (HTTP " + status + ").");
                StringBuilder response = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (response.length() + line.length() > 16384)
                            throw new IllegalStateException("Resposta do serviço de voz excede 16 KiB.");
                        response.append(line);
                    }
                }
                if (status < 200 || status >= 300) throw new IllegalStateException("Serviço de voz retornou HTTP " + status + ".");
                JsonObject json = new JsonParser().parse(response.toString()).getAsJsonObject();
                String text = json.get("text").getAsString().trim();
                if (text.isEmpty()) throw new IllegalStateException("Nenhuma fala foi reconhecida.");
                return text.substring(0, Math.min(500, text.length()));
            } catch (Exception ex) {
                throw new RuntimeException("Falha no reconhecimento de voz local: " + ex.getMessage(), ex);
            } finally { if (connection != null) connection.disconnect(); }
        });
    }

    @Override public String getProviderName() { return "local-http-speech"; }
}
