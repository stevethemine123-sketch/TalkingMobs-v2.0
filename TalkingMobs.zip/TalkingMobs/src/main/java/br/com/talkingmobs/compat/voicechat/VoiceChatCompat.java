package br.com.talkingmobs.compat.voicechat;

import net.minecraftforge.fml.common.Loader;

/** Safe mod-presence check; API event/audio bridge is implemented in the next integration milestone. */
public final class VoiceChatCompat {
    private VoiceChatCompat() { }

    public static boolean isInstalled() {
        return Loader.isModLoaded("voicechat") || Loader.isModLoaded("voicechat_api");
    }
}
