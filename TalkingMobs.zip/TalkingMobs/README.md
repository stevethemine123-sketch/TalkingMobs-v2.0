# Talking Mobs — Minecraft 1.12.2

Versão de desenvolvimento: **0.1.5-dev**  
Alvo: Minecraft 1.12.2 / Forge 14.23.5.2864 / Java 8.

## Recursos presentes no código

- Diálogo de mobs por interação e pelo comando `/talkingmobs falar <mensagem>`.
- Memória persistente limitada por mundo, jogador e criatura.
- Provedores de resposta local/fallback e adaptador HTTP local compatível com API de chat.
- Ponte de reconhecimento de fala local: o cliente envia WAV ao serviço de transcrição em `localhost`, recebe texto e encaminha **somente o texto reconhecido** ao servidor.
- Tecla **V** como push-to-talk no cliente desktop Java Sound; gravação limitada a 8 segundos.
- Pacote de rede servidor recebe texto reconhecido e o encaminha ao comando de conversa.
- Envio online desativado por padrão.

## Reconhecimento de voz (desktop)

1. Habilite `speechRecognitionEnabled=true` em `config/talkingmobs.cfg`.
2. Execute um serviço local de transcrição que aceite `POST /transcribe` com `Content-Type: audio/wav` e cabeçalho `X-Speech-Language`.
3. O serviço deve responder JSON como `{"text":"Olá, aldeão"}`.
4. Entre no mundo, aproxime-se de um mob e segure **V** enquanto fala. Solte V para encerrar a gravação.

O endpoint é restrito a endereço de loopback (`localhost`/`127.0.0.1`/`::1`). O áudio bruto não é transmitido ao servidor Minecraft: a transcrição é que é enviada.

## Android / PojavLauncher

A captura desta versão usa Java Sound, que pode não existir no runtime Android/Pojav. O mod trata essa ausência sem encerrar o jogo, mas **a captura nativa Android ainda precisa de um adaptador próprio**. O reconhecimento por texto e as demais funções continuam sendo a rota alternativa.

## Compilar

Requer Java 8 e Gradle/ForgeGradle para Forge 1.12.2. Execute `gradlew build` em ambiente com as dependências ForgeGradle disponíveis. A compilação ainda não foi confirmada neste ambiente.

## Privacidade

- Reconhecimento desativado por padrão.
- O microfone só é acessado enquanto a tecla V está pressionada.
- O áudio só é enviado ao endpoint local configurado; o código valida que o destino é loopback.
- Nenhum áudio é salvo em disco pelo mod.


## Marco 1.6-dev — saída de voz local e validação

- Adicionada mensagem servidor-cliente para entregar o texto da resposta do mob ao cliente.
- Adicionada ponte TTS opcional via HTTP local: `POST /speak`, JSON `{\"text\":\"...\",\"language\":\"pt_br\"}`, resposta em áudio WAV.
- O endpoint é restrito a loopback e a saída fica desativada por padrão (`speechOutputEnabled=false`).
- No PC, o cliente tenta reproduzir WAV via Java Sound. Em ambientes sem Java Sound (incluindo algumas instalações Android/Pojav), a saída informa que precisa de adaptador nativo.
- O reconhecimento Android nativo ainda requer um companion Android que use a permissão de microfone do sistema e exponha o contrato local; Forge 1.12.2 não oferece API Android de microfone. Não foi incluído um APK.

### Contrato do companion Android/PC

- Transcrição: `POST /transcribe` com `audio/wav` ou conforme o provider existente, retorno JSON com `text`.
- Síntese: `POST /speak` com JSON `text` e `language`, retorno `audio/wav`.
- O serviço deve escutar apenas em `127.0.0.1`, não em interfaces públicas.

### Validação

ZIP e estrutura de arquivos podem ser verificados localmente. A compilação ForgeGradle ainda depende de Java 8 e das dependências ForgeGradle/Gradle; neste ambiente só há Java 21 e não há Gradle instalado/cacheado, então não declarar compilação bem-sucedida. Testes dentro do Minecraft continuam pendentes.
